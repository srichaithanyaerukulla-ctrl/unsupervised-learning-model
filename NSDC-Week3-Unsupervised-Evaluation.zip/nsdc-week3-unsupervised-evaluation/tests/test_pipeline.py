import sys
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.cluster import AgglomerativeClustering, KMeans
from sklearn.metrics import silhouette_score
from sklearn.preprocessing import StandardScaler

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src.analysis import load_dataset


def test_dataset_shape_and_targets_are_separated_from_features():
    frame, X, y, features = load_dataset()
    assert frame.shape[0] == 178
    assert len(features) == 13
    assert X.shape == (178, 13)
    assert len(y.unique()) == 3
    assert "target" not in features and "target_name" not in features


def test_feature_data_is_complete_and_finite():
    _, X, _, _ = load_dataset()
    assert X.isna().sum().sum() == 0
    assert np.isfinite(X.to_numpy()).all()


def test_kmeans_produces_three_clusters_on_selected_configuration():
    _, X, _, _ = load_dataset()
    X_scaled = StandardScaler().fit_transform(X)
    model = KMeans(n_clusters=3, n_init=20, random_state=42)
    labels = model.fit_predict(X_scaled)
    assert len(labels) == len(X)
    assert len(np.unique(labels)) == 3
    assert -1 <= silhouette_score(X_scaled, labels) <= 1


def test_agglomerative_clustering_produces_valid_labels():
    _, X, _, _ = load_dataset()
    X_scaled = StandardScaler().fit_transform(X)
    labels = AgglomerativeClustering(n_clusters=3, linkage="ward").fit_predict(X_scaled)
    assert len(labels) == len(X)
    assert len(np.unique(labels)) == 3


def test_saved_analysis_has_required_artifacts_after_analysis():
    outputs = ROOT / "outputs"
    assert (outputs / "clustering_model_comparison.csv").exists()
    assert (outputs / "classification_model_comparison.csv").exists()
    assert (outputs / "cross_validation_and_tuning_summary.csv").exists()
    assert (ROOT / "visualizations" / "02_pca_cluster_visualization.png").exists()
