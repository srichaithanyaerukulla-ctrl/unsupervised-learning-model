"""Week 3 clustering and model evaluation project."""
