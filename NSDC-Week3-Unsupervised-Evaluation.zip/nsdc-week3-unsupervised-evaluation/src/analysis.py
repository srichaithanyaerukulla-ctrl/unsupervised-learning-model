"""Reproducible Week 3 clustering and model-evaluation workflow.

Run from the project root with: python -m src.analysis
The Wine class labels are excluded from clustering inputs and used only for
post-hoc evaluation and for the separate supervised classification exercise.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from scipy.cluster.hierarchy import dendrogram, linkage
from sklearn.cluster import AgglomerativeClustering, KMeans
from sklearn.decomposition import PCA
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    adjusted_rand_score,
    auc,
    confusion_matrix,
    f1_score,
    normalized_mutual_info_score,
    precision_score,
    recall_score,
    roc_auc_score,
    roc_curve,
    silhouette_score,
)
from sklearn.model_selection import GridSearchCV, StratifiedKFold, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler, label_binarize

ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "data" / "wine_dataset.csv"
OUTPUT_DIR = ROOT / "outputs"
FIG_DIR = ROOT / "visualizations"
RANDOM_STATE = 42


def load_dataset() -> tuple[pd.DataFrame, pd.DataFrame, pd.Series, list[str]]:
    """Load data and separate features from labels without target leakage."""
    frame = pd.read_csv(DATA_PATH)
    feature_cols = [c for c in frame.columns if c not in {"target", "target_name"}]
    X = frame[feature_cols].astype(float)
    y = frame["target"].astype(int)
    if X.isna().any().any():
        raise ValueError("Dataset contains missing feature values.")
    if not np.isfinite(X.to_numpy()).all():
        raise ValueError("Dataset contains non-finite numeric values.")
    return frame, X, y, feature_cols


def _savefig(path: Path) -> None:
    plt.tight_layout()
    plt.savefig(path, dpi=180, bbox_inches="tight")
    plt.close()


def run_clustering(X: pd.DataFrame, y: pd.Series) -> dict[str, Any]:
    """Fit and compare K-Means and hierarchical clustering, then plot diagnostics."""
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    # Tune the number of clusters using the unsupervised silhouette score only.
    k_rows: list[dict[str, float | int]] = []
    k_models: dict[int, KMeans] = {}
    for k in range(2, 7):
        model = KMeans(n_clusters=k, n_init=20, random_state=RANDOM_STATE)
        clusters = model.fit_predict(X_scaled)
        k_models[k] = model
        k_rows.append({
            "n_clusters": k,
            "silhouette_score": float(silhouette_score(X_scaled, clusters)),
            # Label-based metrics are reported only as external post-hoc checks;
            # they are not used to select k.
            "adjusted_rand_index_posthoc": float(adjusted_rand_score(y, clusters)),
            "normalized_mutual_info_posthoc": float(normalized_mutual_info_score(y, clusters)),
            "inertia": float(model.inertia_),
        })
    k_df = pd.DataFrame(k_rows).sort_values("n_clusters")
    k_df.to_csv(OUTPUT_DIR / "kmeans_cluster_tuning.csv", index=False)
    best_k = int(k_df.loc[k_df["silhouette_score"].idxmax(), "n_clusters"])
    kmeans = k_models[best_k]
    km_labels = kmeans.labels_

    # Hierarchical clustering linkage tuning is also selected using silhouette.
    hierarchy_rows: list[dict[str, float | int | str]] = []
    hierarchy_models: dict[str, AgglomerativeClustering] = {}
    for method in ["ward", "complete", "average"]:
        model = AgglomerativeClustering(n_clusters=best_k, linkage=method)
        labels = model.fit_predict(X_scaled)
        hierarchy_models[method] = model
        hierarchy_rows.append({
            "n_clusters": best_k,
            "linkage": method,
            "silhouette_score": float(silhouette_score(X_scaled, labels)),
            "adjusted_rand_index_posthoc": float(adjusted_rand_score(y, labels)),
            "normalized_mutual_info_posthoc": float(normalized_mutual_info_score(y, labels)),
        })
    h_df = pd.DataFrame(hierarchy_rows).sort_values("silhouette_score", ascending=False)
    h_df.to_csv(OUTPUT_DIR / "hierarchical_linkage_comparison.csv", index=False)
    best_linkage = str(h_df.iloc[0]["linkage"])
    agglom = hierarchy_models[best_linkage]
    agg_labels = agglom.fit_predict(X_scaled)

    # Consolidated external/internal validation table for the two chosen approaches.
    cluster_rows = [
        {
            "method": "K-Means",
            "n_clusters": best_k,
            "silhouette_score": float(silhouette_score(X_scaled, km_labels)),
            "adjusted_rand_index": float(adjusted_rand_score(y, km_labels)),
            "normalized_mutual_info": float(normalized_mutual_info_score(y, km_labels)),
            "configuration": "n_init=20; random_state=42",
        },
        {
            "method": f"Agglomerative ({best_linkage})",
            "n_clusters": best_k,
            "silhouette_score": float(silhouette_score(X_scaled, agg_labels)),
            "adjusted_rand_index": float(adjusted_rand_score(y, agg_labels)),
            "normalized_mutual_info": float(normalized_mutual_info_score(y, agg_labels)),
            "configuration": f"linkage={best_linkage}",
        },
    ]
    cluster_df = pd.DataFrame(cluster_rows)
    cluster_df.to_csv(OUTPUT_DIR / "clustering_model_comparison.csv", index=False)

    cluster_assignments = pd.DataFrame({
        "target": y.to_numpy(),
        "target_name": pd.read_csv(DATA_PATH)["target_name"].to_numpy(),
        "kmeans_cluster": km_labels,
        "hierarchical_cluster": agg_labels,
    })
    cluster_assignments.to_csv(OUTPUT_DIR / "cluster_assignments.csv", index=False)

    # Silhouette comparison for K-Means cluster counts.
    plt.figure(figsize=(7.5, 4.5))
    plt.plot(k_df["n_clusters"], k_df["silhouette_score"], marker="o", linewidth=2)
    plt.axvline(best_k, linestyle="--", alpha=0.7, label=f"Selected k = {best_k}")
    plt.xlabel("Number of clusters (k)")
    plt.ylabel("Silhouette score (higher is better)")
    plt.title("K-Means Hyperparameter Tuning: Silhouette Score")
    plt.xticks(range(2, 7))
    plt.legend()
    _savefig(FIG_DIR / "01_kmeans_silhouette_tuning.png")

    # PCA is fitted on standardized features for visualization; clustering is run in 13D.
    pca = PCA(n_components=2, random_state=RANDOM_STATE)
    X_pca = pca.fit_transform(X_scaled)
    var = pca.explained_variance_ratio_
    pca_frame = pd.DataFrame({
        "pc1": X_pca[:, 0], "pc2": X_pca[:, 1], "target": y.to_numpy(),
        "target_name": pd.read_csv(DATA_PATH)["target_name"].to_numpy(),
        "kmeans_cluster": km_labels, "hierarchical_cluster": agg_labels,
    })
    pca_frame.to_csv(OUTPUT_DIR / "pca_projection_and_clusters.csv", index=False)
    fig, axes = plt.subplots(1, 3, figsize=(15, 4.5))
    sns.scatterplot(data=pca_frame, x="pc1", y="pc2", hue="target_name", palette="Set2", s=55, ax=axes[0])
    axes[0].set_title("Known class labels (post-hoc reference)")
    sns.scatterplot(data=pca_frame, x="pc1", y="pc2", hue="kmeans_cluster", palette="tab10", s=55, ax=axes[1])
    axes[1].set_title("K-Means clusters")
    sns.scatterplot(data=pca_frame, x="pc1", y="pc2", hue="hierarchical_cluster", palette="tab10", s=55, ax=axes[2])
    axes[2].set_title(f"Agglomerative ({best_linkage})")
    for ax in axes:
        ax.set_xlabel(f"PC1 ({var[0]*100:.1f}% variance)")
        ax.set_ylabel(f"PC2 ({var[1]*100:.1f}% variance)")
    _savefig(FIG_DIR / "02_pca_cluster_visualization.png")

    # Dendrogram demonstrates hierarchical merge structure (illustrative subset for legibility).
    Z = linkage(X_scaled, method="ward", metric="euclidean")
    plt.figure(figsize=(11, 5))
    dendrogram(Z, truncate_mode="lastp", p=25, show_leaf_counts=True, leaf_rotation=45)
    plt.title("Hierarchical Clustering Dendrogram (Truncated View)")
    plt.xlabel("Merged observations / groups")
    plt.ylabel("Ward linkage distance")
    _savefig(FIG_DIR / "03_hierarchical_dendrogram.png")

    return {
        "n_samples": int(X.shape[0]),
        "n_features": int(X.shape[1]),
        "best_k": best_k,
        "best_hierarchical_linkage": best_linkage,
        "pca_explained_variance_ratio_pc1": float(var[0]),
        "pca_explained_variance_ratio_pc2": float(var[1]),
        "pca_total_variance_2d": float(var.sum()),
        "clustering_comparison": cluster_rows,
        "kmeans_tuning_rows": k_rows,
        "hierarchical_tuning_rows": hierarchy_rows,
    }


def run_classification(X: pd.DataFrame, y: pd.Series) -> dict[str, Any]:
    """Use stratified hold-out evaluation, cross-validation, and grid search."""
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=RANDOM_STATE, stratify=y
    )
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)

    logistic_pipe = Pipeline([
        ("scaler", StandardScaler()),
        ("classifier", LogisticRegression(max_iter=5000, random_state=RANDOM_STATE)),
    ])
    logistic_grid = GridSearchCV(
        logistic_pipe,
        param_grid={"classifier__C": [0.01, 0.1, 1.0, 10.0], "classifier__class_weight": [None, "balanced"]},
        scoring="f1_macro", cv=cv, n_jobs=-1, refit=True, return_train_score=True,
    )
    logistic_grid.fit(X_train, y_train)

    rf_pipe = Pipeline([
        ("classifier", RandomForestClassifier(random_state=RANDOM_STATE, n_jobs=1)),
    ])
    rf_grid = GridSearchCV(
        rf_pipe,
        param_grid={
            "classifier__n_estimators": [100, 200],
            "classifier__max_depth": [None, 5, 10],
            "classifier__min_samples_split": [2, 5],
        },
        scoring="f1_macro", cv=cv, n_jobs=-1, refit=True, return_train_score=True,
    )
    rf_grid.fit(X_train, y_train)

    grids = {"Tuned Logistic Regression": logistic_grid, "Tuned Random Forest": rf_grid}
    metric_rows: list[dict[str, Any]] = []
    confusion_dict: dict[str, list[list[int]]] = {}
    probability_dict: dict[str, np.ndarray] = {}
    cv_rows: list[dict[str, Any]] = []
    for model_name, grid in grids.items():
        estimator = grid.best_estimator_
        pred = estimator.predict(X_test)
        probs = estimator.predict_proba(X_test)
        metric_rows.append({
            "model": model_name,
            "accuracy": float(accuracy_score(y_test, pred)),
            "precision_macro": float(precision_score(y_test, pred, average="macro", zero_division=0)),
            "recall_macro": float(recall_score(y_test, pred, average="macro", zero_division=0)),
            "f1_macro": float(f1_score(y_test, pred, average="macro", zero_division=0)),
            "f1_weighted": float(f1_score(y_test, pred, average="weighted", zero_division=0)),
            "roc_auc_macro_ovr": float(roc_auc_score(y_test, probs, multi_class="ovr", average="macro")),
            "best_cv_f1_macro": float(grid.best_score_),
            "best_params": json.dumps(grid.best_params_, sort_keys=True),
        })
        confusion_dict[model_name] = confusion_matrix(y_test, pred, labels=[0, 1, 2]).tolist()
        probability_dict[model_name] = probs
        cv_rows.append({
            "model": model_name,
            "best_cv_f1_macro": float(grid.best_score_),
            "best_params": json.dumps(grid.best_params_, sort_keys=True),
            "cv_folds": 5,
            "scoring": "f1_macro",
            "train_samples": int(len(X_train)),
            "test_samples": int(len(X_test)),
        })
        pd.DataFrame(grid.cv_results_).sort_values("rank_test_score").to_csv(
            OUTPUT_DIR / ("grid_search_" + ("logistic" if "Logistic" in model_name else "random_forest") + ".csv"),
            index=False,
        )

    metric_df = pd.DataFrame(metric_rows)
    metric_df.to_csv(OUTPUT_DIR / "classification_model_comparison.csv", index=False)
    pd.DataFrame(cv_rows).to_csv(OUTPUT_DIR / "cross_validation_and_tuning_summary.csv", index=False)
    for model_name, matrix in confusion_dict.items():
        safe_name = "logistic" if "Logistic" in model_name else "random_forest"
        pd.DataFrame(matrix, index=["Actual 0", "Actual 1", "Actual 2"], columns=["Predicted 0", "Predicted 1", "Predicted 2"]).to_csv(
            OUTPUT_DIR / f"confusion_matrix_{safe_name}.csv", index=True
        )

    # Confusion matrix comparison.
    fig, axes = plt.subplots(1, 2, figsize=(10.5, 4.5))
    for ax, (model_name, matrix) in zip(axes, confusion_dict.items()):
        sns.heatmap(np.asarray(matrix), annot=True, fmt="d", cmap="Blues", cbar=False, ax=ax,
                    xticklabels=["Class 0", "Class 1", "Class 2"],
                    yticklabels=["Class 0", "Class 1", "Class 2"])
        ax.set_title(model_name)
        ax.set_xlabel("Predicted label")
        ax.set_ylabel("True label")
    _savefig(FIG_DIR / "04_classification_confusion_matrices.png")

    # Multiclass one-vs-rest ROC curves. Each model contributes one curve per class.
    y_test_bin = label_binarize(y_test, classes=[0, 1, 2])
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.8))
    class_names = ["class_0", "class_1", "class_2"]
    for ax, (model_name, probs) in zip(axes, probability_dict.items()):
        for i, class_name in enumerate(class_names):
            fpr, tpr, _ = roc_curve(y_test_bin[:, i], probs[:, i])
            ax.plot(fpr, tpr, label=f"{class_name} (AUC={auc(fpr,tpr):.3f})", linewidth=1.8)
        ax.plot([0, 1], [0, 1], "k--", alpha=0.6, label="Chance")
        ax.set_title(model_name)
        ax.set_xlabel("False Positive Rate")
        ax.set_ylabel("True Positive Rate")
        ax.legend(fontsize=8, loc="lower right")
    _savefig(FIG_DIR / "05_multiclass_roc_curves.png")

    # Compact metric comparison plot.
    plot_df = metric_df.melt(id_vars="model", value_vars=["accuracy", "precision_macro", "recall_macro", "f1_macro", "roc_auc_macro_ovr"],
                             var_name="metric", value_name="score")
    plt.figure(figsize=(10, 5))
    ax = sns.barplot(data=plot_df, x="metric", y="score", hue="model")
    plt.ylim(0, 1.05)
    plt.xticks(rotation=20, ha="right")
    plt.ylabel("Score")
    plt.title("Held-Out Classification Metrics")
    ax.legend(title="Model", loc="center left", bbox_to_anchor=(1.01, 0.5), frameon=False)
    _savefig(FIG_DIR / "06_classification_metrics_comparison.png")

    return {
        "train_samples": int(len(X_train)),
        "test_samples": int(len(X_test)),
        "classification_results": metric_rows,
        "cross_validation_summary": cv_rows,
        "class_labels": [0, 1, 2],
        "class_names": ["class_0", "class_1", "class_2"],
        "confusion_matrices": confusion_dict,
    }


def run_analysis() -> dict[str, Any]:
    frame, X, y, feature_cols = load_dataset()
    clustering = run_clustering(X, y)
    classification = run_classification(X, y)
    result = {
        "project": "Week 3: Unsupervised Learning and Model Evaluation",
        "dataset": "Scikit-learn Wine Recognition dataset",
        "n_samples": int(frame.shape[0]),
        "n_features": int(len(feature_cols)),
        "class_counts": {str(k): int(v) for k, v in y.value_counts().sort_index().items()},
        "feature_names": feature_cols,
        "random_state": RANDOM_STATE,
        "clustering": clustering,
        "classification": classification,
        "leakage_note": "target/target_name are excluded from clustering features. Labels are used only for post-hoc clustering metrics and a separate supervised evaluation.",
    }
    (OUTPUT_DIR / "analysis_results.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(f"Dataset: {frame.shape[0]} samples, {len(feature_cols)} numeric features")
    print(f"Selected K-Means k by silhouette: {clustering['best_k']}")
    print(f"Selected hierarchical linkage by silhouette: {clustering['best_hierarchical_linkage']}")
    print("Clustering comparison:")
    print(pd.read_csv(OUTPUT_DIR / "clustering_model_comparison.csv").to_string(index=False))
    print("Classification comparison:")
    print(pd.read_csv(OUTPUT_DIR / "classification_model_comparison.csv")[["model", "accuracy", "precision_macro", "recall_macro", "f1_macro", "roc_auc_macro_ovr", "best_cv_f1_macro"]].to_string(index=False))
    return result


if __name__ == "__main__":
    run_analysis()
