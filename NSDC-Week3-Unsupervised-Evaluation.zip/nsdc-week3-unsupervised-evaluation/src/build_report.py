"""Build the Week 3 Word report from actual analysis outputs.
Run: python -m src.build_report
"""
from __future__ import annotations

import json
from pathlib import Path

import pandas as pd
from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "docs" / "Week3_Unsupervised_Learning_Model_Evaluation_Report.docx"
NAVY = "17365D"
BLUE = "1F4E79"
TEAL = "0F6B78"
PALE = "EAF2F8"
PALE2 = "F4F8FB"
DARK = "243746"
MUTED = "5B6573"


def shade(cell, fill: str) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_cell_margins(cell, top=80, start=90, bottom=80, end=90) -> None:
    tc = cell._tc
    tc_pr = tc.get_or_add_tcPr()
    mar = tc_pr.first_child_found_in("w:tcMar")
    if mar is None:
        mar = OxmlElement("w:tcMar")
        tc_pr.append(mar)
    for m, v in [("top", top), ("start", start), ("bottom", bottom), ("end", end)]:
        node = mar.find(qn(f"w:{m}"))
        if node is None:
            node = OxmlElement(f"w:{m}")
            mar.append(node)
        node.set(qn("w:w"), str(v))
        node.set(qn("w:type"), "dxa")


def set_repeat_table_header(row) -> None:
    tr_pr = row._tr.get_or_add_trPr()
    tbl_header = OxmlElement("w:tblHeader")
    tbl_header.set(qn("w:val"), "true")
    tr_pr.append(tbl_header)


def set_cell_text(cell, text: str, *, bold=False, color=DARK, size=8.5, align=None):
    cell.text = ""
    p = cell.paragraphs[0]
    p.paragraph_format.space_after = Pt(0)
    p.paragraph_format.space_before = Pt(0)
    if align is not None:
        p.alignment = align
    r = p.add_run(str(text))
    r.bold = bold
    r.font.name = "Aptos"
    r.font.size = Pt(size)
    r.font.color.rgb = RGBColor.from_string(color)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
    set_cell_margins(cell)


def add_table(doc, headers, rows, widths=None, size=8.2):
    table = doc.add_table(rows=1, cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.style = "Table Grid"
    header = table.rows[0]
    set_repeat_table_header(header)
    for i, h in enumerate(headers):
        set_cell_text(header.cells[i], h, bold=True, color="FFFFFF", size=size)
        shade(header.cells[i], NAVY)
    for row_i, row in enumerate(rows):
        cells = table.add_row().cells
        for i, val in enumerate(row):
            set_cell_text(cells[i], val, size=size)
            if row_i % 2 == 0:
                shade(cells[i], PALE2)
    if widths:
        for row in table.rows:
            for i, w in enumerate(widths):
                row.cells[i].width = Inches(w)
    doc.add_paragraph().paragraph_format.space_after = Pt(1)
    return table


def add_field(paragraph, field: str):
    run = paragraph.add_run()
    fld_char1 = OxmlElement("w:fldChar")
    fld_char1.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = field
    fld_char2 = OxmlElement("w:fldChar")
    fld_char2.set(qn("w:fldCharType"), "end")
    run._r.append(fld_char1)
    run._r.append(instr)
    run._r.append(fld_char2)


def setup_doc(doc: Document) -> None:
    sec = doc.sections[0]
    sec.top_margin = Inches(0.66)
    sec.bottom_margin = Inches(0.62)
    sec.left_margin = Inches(0.74)
    sec.right_margin = Inches(0.74)
    sec.header_distance = Inches(0.28)
    sec.footer_distance = Inches(0.3)

    styles = doc.styles
    normal = styles["Normal"]
    normal.font.name = "Aptos"
    normal.font.size = Pt(9.5)
    normal.font.color.rgb = RGBColor.from_string(DARK)
    normal.paragraph_format.space_after = Pt(5)
    normal.paragraph_format.line_spacing = 1.08
    for name, size, color in [("Title", 29, NAVY), ("Heading 1", 17, NAVY), ("Heading 2", 12.5, TEAL), ("Heading 3", 10.5, BLUE)]:
        st = styles[name]
        st.font.name = "Aptos Display" if name in ("Title", "Heading 1") else "Aptos"
        st.font.size = Pt(size)
        st.font.bold = True
        st.font.color.rgb = RGBColor.from_string(color)
        st.paragraph_format.space_before = Pt(10 if name != "Title" else 0)
        st.paragraph_format.space_after = Pt(5)
        st.paragraph_format.keep_with_next = True

    header = sec.header.paragraphs[0]
    header.alignment = WD_ALIGN_PARAGRAPH.LEFT
    header.text = "NSDC | VIRTUAL DATA SCIENCE WITH PYTHON APPRENTICE INTERN"
    for r in header.runs:
        r.font.name = "Aptos"
        r.font.size = Pt(7.5)
        r.font.bold = True
        r.font.color.rgb = RGBColor.from_string(TEAL)
    footer = sec.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = footer.add_run("WEEK 3  •  UNSUPERVISED LEARNING & MODEL EVALUATION  |  PAGE ")
    r.font.size = Pt(7.5)
    r.font.color.rgb = RGBColor.from_string(MUTED)
    add_field(footer, "PAGE")


def add_bullet(doc, text: str):
    p = doc.add_paragraph(style="List Bullet")
    p.paragraph_format.left_indent = Inches(0.23)
    p.paragraph_format.first_line_indent = Inches(-0.12)
    p.paragraph_format.space_after = Pt(2.5)
    p.add_run(text)
    return p


def add_figure(doc, filename: str, caption: str, width=6.7):
    path = ROOT / "visualizations" / filename
    if not path.exists():
        return
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(2)
    p.paragraph_format.space_after = Pt(2)
    p.add_run().add_picture(str(path), width=Inches(width))
    cap = doc.add_paragraph()
    cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
    cap.paragraph_format.space_after = Pt(7)
    run = cap.add_run(caption)
    run.italic = True
    run.font.size = Pt(8.5)
    run.font.color.rgb = RGBColor.from_string(MUTED)


def add_callout(doc, title: str, text: str):
    t = doc.add_table(rows=1, cols=1)
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    cell = t.cell(0, 0)
    shade(cell, PALE)
    cell.text = ""
    p = cell.paragraphs[0]
    p.paragraph_format.space_after = Pt(2)
    r = p.add_run(title + "\n")
    r.bold = True
    r.font.color.rgb = RGBColor.from_string(BLUE)
    r.font.size = Pt(9.5)
    r2 = p.add_run(text)
    r2.font.size = Pt(9)
    r2.font.color.rgb = RGBColor.from_string(DARK)
    set_cell_margins(cell, top=140, bottom=140, start=160, end=160)
    doc.add_paragraph().paragraph_format.space_after = Pt(1)


def fmt(v, digits=4):
    if isinstance(v, (int, float)):
        return f"{v:.{digits}f}"
    return str(v)


def main():
    results_path = ROOT / "outputs" / "analysis_results.json"
    if not results_path.exists():
        raise FileNotFoundError("Run `python -m src.analysis` before building the report.")
    data = json.loads(results_path.read_text(encoding="utf-8"))
    cluster_df = pd.read_csv(ROOT / "outputs" / "clustering_model_comparison.csv")
    km_tune = pd.read_csv(ROOT / "outputs" / "kmeans_cluster_tuning.csv")
    hier_tune = pd.read_csv(ROOT / "outputs" / "hierarchical_linkage_comparison.csv")
    class_df = pd.read_csv(ROOT / "outputs" / "classification_model_comparison.csv")
    cv_df = pd.read_csv(ROOT / "outputs" / "cross_validation_and_tuning_summary.csv")

    doc = Document()
    setup_doc(doc)

    # Cover page
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(55)
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run("WEEK 3 PROJECT REPORT")
    r.bold = True
    r.font.size = Pt(12)
    r.font.color.rgb = RGBColor.from_string(TEAL)

    p = doc.add_paragraph(style="Title")
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(18)
    p.add_run("Unsupervised Learning\n& Model Evaluation")

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(12)
    r = p.add_run("K-Means • Hierarchical Clustering • PCA • Cross-Validation • Hyperparameter Tuning")
    r.font.size = Pt(11)
    r.font.color.rgb = RGBColor.from_string(MUTED)

    doc.add_paragraph().paragraph_format.space_after = Pt(14)
    add_callout(doc, "Project at a glance", f"Dataset: Wine Recognition dataset  |  {data['n_samples']} observations  |  {data['n_features']} numeric features  |  3 reference classes\nSelected clustering: K-Means k={data['clustering']['best_k']} by silhouette score; hierarchical linkage={data['clustering']['best_hierarchical_linkage']}.\nSupervised evaluation: two tuned classifiers, stratified 75/25 hold-out split, and 5-fold stratified cross-validation.")

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(45)
    r = p.add_run("Submitted for: Virtual Data Science with Python Apprentice Intern\nTechnical focus: Unsupervised Learning and Model Evaluation")
    r.font.size = Pt(10)
    r.font.color.rgb = RGBColor.from_string(DARK)
    doc.add_page_break()

    doc.add_heading("1. Executive Summary", level=1)
    doc.add_paragraph(
        "This project demonstrates the use of unsupervised clustering to explore the structure of a labelled but feature-only chemical-analysis dataset, then separately demonstrates supervised model evaluation concepts requested in the task. The clustering stage excludes the known class labels from model inputs, standardizes the 13 numeric features, tunes K-Means cluster count using silhouette score, and compares the result with Agglomerative (hierarchical) clustering. Principal Component Analysis (PCA) compresses the standardized features into two dimensions for visualization."
    )
    doc.add_paragraph(
        f"Silhouette tuning selected {data['clustering']['best_k']} K-Means clusters. K-Means achieved silhouette={cluster_df.iloc[0]['silhouette_score']:.3f} and post-hoc Adjusted Rand Index (ARI)={cluster_df.iloc[0]['adjusted_rand_index']:.3f}. The selected hierarchical method ({data['clustering']['best_hierarchical_linkage']}) achieved silhouette={cluster_df.iloc[1]['silhouette_score']:.3f} and ARI={cluster_df.iloc[1]['adjusted_rand_index']:.3f}. The first two PCA components account for {data['clustering']['pca_total_variance_2d']*100:.1f}% of standardized-feature variance."
    )
    best_cls = class_df.loc[class_df["f1_macro"].idxmax()]
    doc.add_paragraph(
        f"For the separate classification experiment, tuned Logistic Regression and Random Forest were evaluated on a stratified held-out set of {data['classification']['test_samples']} records. Both achieved accuracy={best_cls['accuracy']:.3f}, macro F1={best_cls['f1_macro']:.3f}, and macro one-vs-rest ROC-AUC={best_cls['roc_auc_macro_ovr']:.3f} on this split; their best five-fold cross-validation macro-F1 was approximately {class_df['best_cv_f1_macro'].max():.3f}. These high test scores describe this run on a small benchmark dataset and should not be treated as a guarantee of future performance."
    )

    doc.add_heading("2. Task Statement and Objectives", level=1)
    doc.add_paragraph("Task statement: Understand clustering algorithms such as K-Means and Hierarchical Clustering, learn dimensionality reduction, and apply evaluation concepts including cross-validation, confusion matrices, precision, recall, F1-score, ROC-AUC, and hyperparameter tuning. The deliverable is a clustering experiment and a model evaluation report.")
    add_table(doc, ["ID", "Requirement", "Implementation and evidence", "Status"], [
        ["R1", "K-Means and hierarchical clustering", "K-Means k tuning; Agglomerative clustering with Ward, Complete, and Average linkage; comparison CSVs and plots.", "PASS"],
        ["R2", "Dimensionality reduction", "PCA projection to 2 dimensions with explained-variance proportions; visualization only, not clustering input reduction.", "PASS"],
        ["R3", "Cross-validation and hyperparameter tuning", "Stratified 5-fold CV and GridSearchCV for Logistic Regression and Random Forest, plus silhouette-based cluster-count tuning.", "PASS"],
        ["R4", "Confusion matrix, precision, recall, F1, ROC-AUC", "Held-out classification metrics, two confusion matrices, multiclass one-vs-rest ROC curves.", "PASS"],
        ["R5", "Clustering run and report", "Reproducible code, assignment file, metrics, six figures, Word report, README, and automated tests.", "PASS"],
    ], widths=[0.45, 1.55, 4.45, 0.55], size=7.5)

    doc.add_heading("3. Dataset and Preparation", level=1)
    doc.add_paragraph(
        "The included CSV is based on the Wine Recognition dataset distributed by Scikit-learn and originally hosted by the UCI Machine Learning Repository. It contains 178 records, 13 continuous chemical-analysis features, and three reference classes. The numeric target and readable target name are retained in the file for evaluation, but are explicitly excluded from the clustering feature matrix. All feature values are numeric and complete, so no imputation was required for this dataset."
    )
    add_table(doc, ["Item", "Value"], [
        ["Records", "178"],
        ["Input features", "13 numeric features"],
        ["Reference class counts", str(data["class_counts"])],
        ["Missing numeric feature cells", "0"],
        ["Feature scaling", "StandardScaler (zero mean / unit variance on each feature)"],
        ["Random seed", str(data["random_state"])],
    ], widths=[2.2, 4.8], size=8.3)
    add_callout(doc, "Leakage control", data["leakage_note"])

    doc.add_heading("4. Clustering Methodology", level=1)
    doc.add_heading("4.1 K-Means", level=2)
    doc.add_paragraph("K-Means partitions observations into a preselected number of clusters by iteratively assigning each observation to its nearest centroid and updating centroids. Since distance is sensitive to feature scale, all 13 features were standardized first. Candidate cluster counts k=2 through k=6 were compared using silhouette score; the highest silhouette value selected k. A fixed random seed and n_init=20 improve reproducibility and reduce dependence on one centroid initialization.")
    doc.add_heading("4.2 Hierarchical / Agglomerative Clustering", level=2)
    doc.add_paragraph("Agglomerative clustering begins with observations as separate clusters and merges clusters according to a linkage rule. Ward, Complete, and Average linkages were compared at the selected cluster count. The linkage with the highest silhouette score was retained for the main comparison. A truncated dendrogram is also included to illustrate the hierarchy of merges.")
    doc.add_heading("4.3 Clustering Metrics", level=2)
    add_bullet(doc, "Silhouette score: an internal measure of within-cluster cohesion versus separation; values closer to 1 generally indicate clearer separation, while values near 0 indicate overlapping clusters.")
    add_bullet(doc, "Adjusted Rand Index (ARI): an external comparison of cluster assignments with known reference labels, adjusted for chance. It is calculated only after clustering and was not used to choose k.")
    add_bullet(doc, "Normalized Mutual Information (NMI): an external measure of shared information between assignments and reference labels. Cluster IDs can be permuted, so direct numeric equality of cluster IDs is not expected.")

    doc.add_heading("5. Clustering Results", level=1)
    rows = []
    for _, row in cluster_df.iterrows():
        rows.append([row["method"], int(row["n_clusters"]), fmt(row["silhouette_score"], 3), fmt(row["adjusted_rand_index"], 3), fmt(row["normalized_mutual_info"], 3), row["configuration"]])
    add_table(doc, ["Method", "k", "Silhouette", "ARI", "NMI", "Configuration"], rows, widths=[1.45, 0.35, 0.8, 0.55, 0.55, 2.65], size=7.5)
    add_figure(doc, "01_kmeans_silhouette_tuning.png", "Figure 1. Silhouette score across candidate K-Means cluster counts. Selection used silhouette, not target labels.", width=6.55)
    add_figure(doc, "02_pca_cluster_visualization.png", f"Figure 2. PCA visualization of standardized inputs. The first two PCs explain {data['clustering']['pca_total_variance_2d']*100:.1f}% of total variance; clustering itself was conducted in the original 13-feature space.", width=6.85)

    doc.add_heading("5.1 K-Means Cluster-Count Tuning", level=2)
    tune_rows = [[int(row["n_clusters"]), fmt(row["silhouette_score"], 4), fmt(row["inertia"], 1), fmt(row["adjusted_rand_index_posthoc"], 4), fmt(row["normalized_mutual_info_posthoc"], 4)] for _, row in km_tune.iterrows()]
    add_table(doc, ["k", "Silhouette", "Inertia", "Post-hoc ARI", "Post-hoc NMI"], tune_rows, widths=[0.5, 1.15, 1.15, 1.35, 1.35], size=7.6)
    doc.add_paragraph("The silhouette score peaked at k=3 (approximately 0.285), so three clusters were selected without consulting the reference classes. K-Means ARI was high (approximately 0.897), indicating strong post-hoc agreement with the reference labels. However, the moderate silhouette score suggests the cluster boundaries are not perfectly separated in the full feature space.")

    doc.add_heading("5.2 Hierarchical Linkage Comparison", level=2)
    ht_rows = [[row["linkage"], fmt(row["silhouette_score"], 4), fmt(row["adjusted_rand_index_posthoc"], 4), fmt(row["normalized_mutual_info_posthoc"], 4)] for _, row in hier_tune.iterrows()]
    add_table(doc, ["Linkage", "Silhouette", "Post-hoc ARI", "Post-hoc NMI"], ht_rows, widths=[1.25, 1.35, 1.4, 1.4], size=7.8)
    add_figure(doc, "03_hierarchical_dendrogram.png", "Figure 3. Truncated Ward dendrogram illustrating progressive cluster merges.", width=6.7)
    doc.add_paragraph("Ward linkage provided the best silhouette among the three tested linkage options. Average linkage performed notably worse on the combined standardized feature set. This reinforces that hierarchical results can vary with the linkage definition and data geometry.")

    doc.add_heading("6. Dimensionality Reduction with PCA", level=1)
    doc.add_paragraph(
        f"Principal Component Analysis was applied after standardization to represent the 13-dimensional feature space in two orthogonal components for visualization. PC1 explains {data['clustering']['pca_explained_variance_ratio_pc1']*100:.1f}% and PC2 explains {data['clustering']['pca_explained_variance_ratio_pc2']*100:.1f}%, for a combined {data['clustering']['pca_total_variance_2d']*100:.1f}%. PCA makes structure easier to inspect but discards information in the remaining components. Therefore, the 2D plot is a visualization aid; it is not evidence that all structure is represented in two dimensions.")

    doc.add_heading("7. Supervised Model Evaluation Methodology", level=1)
    doc.add_paragraph("The task also asks for evaluation concepts that apply to labelled prediction tasks. To demonstrate them separately from clustering, two classifiers were trained to predict the known Wine class labels from the 13 numeric features. The data was split once into 75% training and 25% test data using stratification (133 train records and 45 hold-out records). Hyperparameter search and cross-validation operated on training data only. The test set was held out until final scoring.")
    doc.add_heading("7.1 Cross-Validation and Hyperparameter Tuning", level=2)
    add_bullet(doc, "StratifiedKFold with 5 folds and shuffling was used so each fold approximately retained the class proportions.")
    add_bullet(doc, "GridSearchCV optimized macro F1, giving equal weight to each class's F1 score during parameter selection.")
    add_bullet(doc, "Logistic Regression search: C ∈ {0.01, 0.1, 1, 10} and class_weight ∈ {None, balanced}; StandardScaler is inside the pipeline to avoid fold-level scaling leakage.")
    add_bullet(doc, "Random Forest search: n_estimators ∈ {100, 200}, max_depth ∈ {None, 5, 10}, and min_samples_split ∈ {2, 5}.")
    doc.add_heading("7.2 Evaluation Metrics", level=2)
    add_bullet(doc, "Accuracy: fraction of all predictions that are correct.")
    add_bullet(doc, "Macro precision, recall, and F1: calculate each metric per class and take the unweighted mean, preventing the largest class from dominating the summary.")
    add_bullet(doc, "ROC-AUC: macro one-vs-rest multiclass ROC-AUC summarizes ranking quality for each class against all other classes.")
    add_bullet(doc, "Confusion matrix: shows the counts of true versus predicted classes, making individual class errors visible.")

    doc.add_heading("8. Classification Results", level=1)
    cls_rows = []
    for _, row in class_df.iterrows():
        cls_rows.append([row["model"], fmt(row["accuracy"], 3), fmt(row["precision_macro"], 3), fmt(row["recall_macro"], 3), fmt(row["f1_macro"], 3), fmt(row["roc_auc_macro_ovr"], 3), fmt(row["best_cv_f1_macro"], 4)])
    add_table(doc, ["Model", "Accuracy", "Precision (M)", "Recall (M)", "F1 (M)", "ROC-AUC (M)", "CV F1 (M)"], cls_rows, widths=[1.35, 0.65, 0.9, 0.75, 0.6, 0.8, 0.7], size=7.1)
    doc.add_paragraph("Both models reached perfect classification scores on the held-out set in this run. This should be interpreted cautiously: the benchmark contains only 178 samples and is relatively separable, while the test set contains 45 records. Cross-validation macro-F1 was approximately 0.985, which is a more informative indicator of performance variation than the single perfect split alone. Evaluation scores remain dataset- and split-dependent.")

    cv_rows = []
    for _, row in cv_df.iterrows():
        cv_rows.append([row["model"], fmt(row["best_cv_f1_macro"], 5), row["best_params"], f"{int(row['cv_folds'])}-fold; {int(row['train_samples'])} train / {int(row['test_samples'])} test"])
    add_table(doc, ["Model", "Best CV macro-F1", "Selected parameters", "Evaluation design"], cv_rows, widths=[1.35, 1.05, 2.7, 1.55], size=7.2)
    add_figure(doc, "04_classification_confusion_matrices.png", "Figure 4. Confusion matrices on the stratified held-out test set.", width=6.15)
    add_figure(doc, "05_multiclass_roc_curves.png", "Figure 5. One-vs-rest ROC curves for each Wine class on the held-out test set.", width=6.7)
    add_figure(doc, "06_classification_metrics_comparison.png", "Figure 6. Comparison of held-out classification metrics.", width=6.55)

    doc.add_heading("9. Critical Discussion, Errors, and Limitations", level=1)
    doc.add_heading("9.1 Clustering Interpretation", level=2)
    doc.add_paragraph("K-Means outperformed the selected Ward hierarchical solution on the main internal and external scores: its silhouette was slightly higher and its ARI/NMI agreement with reference labels was stronger. The ARI/NMI values are only post-hoc checks because clustering has no target labels during fitting. A silhouette near 0.28 indicates moderate rather than extremely clear separation, so some overlap in full-dimensional feature space remains. Cluster numbering itself has no class meaning.")
    doc.add_heading("9.2 Classification Error Review", level=2)
    doc.add_paragraph("No misclassifications appeared in the 45-record hold-out confusion matrices for either tuned classifier in this fixed run. However, zero observed test errors do not establish zero real-world error. The small dataset, the particular random split, and the relatively distinct classes may contribute to the result. The cross-validation macro-F1 below 1.0 confirms that performance is not perfect across all training folds.")
    doc.add_heading("9.3 Limitations and Next Steps", level=2)
    add_bullet(doc, "Use repeated stratified cross-validation or nested cross-validation to estimate variability and reduce the influence of a single split.")
    add_bullet(doc, "Validate the model and clusters on additional independent or domain-specific data before any real-world use.")
    add_bullet(doc, "Try other scaling choices and clustering methods such as DBSCAN; use stability analysis to see whether cluster assignments persist under resampling.")
    add_bullet(doc, "Interpret feature contributions and examine domain meaning before treating clusters as operational categories.")
    add_bullet(doc, "Keep unsupervised and supervised evaluations distinct: ROC-AUC and confusion matrices evaluate label prediction, not clustering quality.")

    doc.add_heading("10. Reproducibility and Validation", level=1)
    doc.add_paragraph("The repository contains the dataset, the analysis script, generated CSV outputs, visualizations, automated tests, requirements, README, and this Word report. The workflow uses a fixed random state of 42. Run the following commands from the repository root:")
    code = doc.add_paragraph()
    code.paragraph_format.left_indent = Inches(0.2)
    code.paragraph_format.space_before = Pt(2)
    code.paragraph_format.space_after = Pt(6)
    r = code.add_run("python -m pip install -r requirements.txt\npython -m src.analysis\npython -m src.build_report\npython -m pytest -q")
    r.font.name = "Consolas"
    r.font.size = Pt(8.5)
    r.font.color.rgb = RGBColor.from_string(BLUE)
    doc.add_paragraph("The automated tests check that features are separated from target labels, data features are complete and finite, K-Means and Agglomerative clustering produce valid clusters, and key generated artifacts exist.")

    doc.add_heading("11. Submission Description (250+ Words)", level=1)
    desc = (
        "This report documents the Week 3 Unsupervised Learning and Model Evaluation project using Python and Scikit-learn. The objective is to demonstrate clustering methods, dimensionality reduction, and model-evaluation practices in a reproducible workflow. The Wine Recognition dataset, containing 178 observations and 13 numeric chemical-analysis features, was used for the experiments. The known class labels were excluded from all clustering inputs to prevent target leakage. Features were standardized before distance-based analysis, and K-Means clustering was evaluated for candidate cluster counts from two to six using silhouette score. The best cluster count was selected using this internal unsupervised criterion. Agglomerative Hierarchical Clustering was also implemented, and Ward, Complete, and Average linkage settings were compared. Silhouette score was used to review cluster cohesion and separation, while Adjusted Rand Index and Normalized Mutual Information were calculated afterward as external comparisons against the reference labels. Principal Component Analysis was used to reduce the 13-dimensional feature space to two components for visualization, with the explained variance documented so the information loss is clear.\n\n"
        "To demonstrate the evaluation concepts listed in the task, a separate supervised classification experiment compared tuned Logistic Regression and Random Forest. A stratified 75/25 train-test split was used, and five-fold stratified cross-validation with GridSearchCV selected hyperparameters based on macro F1-score. The report includes accuracy, macro precision, macro recall, macro F1-score, multiclass one-vs-rest ROC-AUC, confusion matrices, ROC curves, cross-validation summaries, and parameter search results. The code, dataset, generated CSV outputs, visualizations, automated checks, requirements file, and GitHub-ready README are included in the project package. Results are discussed with limitations: the dataset is small, the fixed test split produced very high scores, and further external validation would be required before making real-world performance claims. The report distinguishes unsupervised cluster-quality measures from supervised classification metrics and explains how each result should be interpreted."
    )
    desc_para = doc.add_paragraph(desc)
    desc_para.paragraph_format.keep_together = True

    doc.add_heading("12. References", level=1)
    add_bullet(doc, "Scikit-learn Developers. load_wine dataset documentation: https://scikit-learn.org/stable/modules/generated/sklearn.datasets.load_wine.html")
    add_bullet(doc, "UCI Machine Learning Repository. Wine Recognition dataset: https://archive.ics.uci.edu/dataset/109/wine")
    add_bullet(doc, "Scikit-learn documentation: KMeans, AgglomerativeClustering, PCA, GridSearchCV, StratifiedKFold, classification metrics, and model selection: https://scikit-learn.org/stable/")

    OUT.parent.mkdir(parents=True, exist_ok=True)
    doc.save(OUT)
    print(f"Report saved to: {OUT}")
    print(f"Submission-description word count: {len(desc.split())}")


if __name__ == "__main__":
    main()
